# Back to terminal 

You can run the following either in Jupyter/JupyterLab web-based terminal or
using your preferred terminal emulator. The syntax and capabilities will
slightly depends on your platform. 

## Prompt toolkit. 

IPython interface is base on `prompt_toolkit` since version 5.0. 
    - Multiline editting
    - Inference of when to execute vs a new line. 
    - Tab completion
    - edit and subprocesses
