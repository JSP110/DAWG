# Exercises 2

Remove all the sticky notes from your screen :-) and attempt the following.
These are _guidelines_, feel free to ere on the side of workflow and
options that suits _you_ if you find them best. 

Keep in mind, if something is not intuitive, or not in the place you expected it, write
it down (for example on the red sticky note), and give it to us at the break.

## Running things


- Binding multiple documents to the same kernel
    - Notebook + console workflow
        - Open Notebook A and B, 
        - change notebook B kernel to be the same as "Notebook A"
        - See how state is shared.
    - Markdown + console workflow; Python code file + console workflow
        - Open "report.md" and follow instructions. 
    - Go to the Running tab to shut down all kernels

- Try arranging different layout, and refresh the page. Get a feeling of which layout element persist across refresh
- Try to find information about "single-document mode"
